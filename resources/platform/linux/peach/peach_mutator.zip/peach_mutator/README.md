# Peach Mutator Development Guide

## Overview

This is a custom mutator for libFuzzer that uses Peach pits to parse
and mutate inputs. It took inspiration from AFL Smart, but just uses
Peach's default mutations rather than custom ones like AFL-Smart does.

The mutator consists of the following files:

**custom_mutator.c**: Where `LLVMFuzzerCustomMutator` lives. This is the
bridge between the python mutator and libFuzzer. This is what is
compiled into peach.so.

**mutate.py**: Entry point for the mutator. Takes data, size, pit info 
and a seed and returns the mutated data.

**parser.py**: Uses the DataCracker from Peach to parse the data into a
tree used by peach.

**mutator.py**: Takes a data_model returned by the parser and performs
random Peach mutations on it.

## How to compile: 
From the src directory:
```
clang -shared -o peach.so -I /usr/include/python3.7/ custom_mutator.c -lpython3.7m -fPIC
```

## To run locally:
1) Make sure you are in a Python3 virtual environment and
    and install dependencies:
    ```
    python3 -m venv ENV
    source ENV/bin/activate
    pip3 install -r requirements.txt
    ```
2) Add `src` and `third_party/Peach` to PYTHONPATH.
    ```
    export PYTHONPATH=$(pwd)/src
    export PYTHONPATH=$(pwd)/third_party/peach
    ```
3) Set PIT_TITLE and PIT_FILENAME environment variables
    ```
   export PIT_TITLE=PDF
   export PIT_FILENAME=path/PDF.xml
    ```
4) SET LD_PRELOAD to peach.so
    ```
    export LD_PRELOAD=$(pwd)/src/peach.so
    ```

## Common errors:
```
==19643==ERROR: AddressSanitizer: SEGV on unknown address 0x000000000008 (pc 0x7f501bdc3345 bp 0x7ffe6e69eed0 sp 0x7ffe6e69eea0 T0)
==19643==The signal is caused by a READ memory access.
==19643==Hint: address points to the zero page.
    #0 0x7f501bdc3345 in PyObject_GetAttrString (/lib/x86_64-linux-gnu/libpython3.7m.so.1.0+0x21f345)

```
A segfault occurs when an error occurs in python. This is often
due to an incorrectly set PYTHONPATH or not being in a Python3
environment

This was recently converted from Python2 to Python3, so an 
occasional unicode error might pop up that was not caught
during the transition. This will also look like a segfault.
In order to debug, you can run the mutator using src/test_pit.py