# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Peach Parser."""

from builtins import object
from Peach.Analyzers import PitXmlAnalyzer
from Peach.Engine.incoming import DataCracker
from Peach.publisher import Publisher
from Peach.publisher import PublisherBuffer


class Parser(object):
  """Parser object takes a peach pit and will parse files of that type."""

  def __init__(self, pit_path, template_name):
    analyzer = PitXmlAnalyzer()
    pit_path = 'file:' + pit_path
    self._peach = analyzer.asParser(pit_path)
    self._pub = Publisher()
    self._data_model = self._peach.templates[template_name]

  def parse(self, data):
    """Uses Peaches DataCracker to parse a file into a DataModel tree."""
    buff = PublisherBuffer(None, data, True)
    cracker = DataCracker(self._peach)
    cracker.optmizeModelForCracking(self._data_model, True)
    cracker.crackData(self._data_model, buff)

    return self._data_model
