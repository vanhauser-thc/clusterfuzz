# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
from future import standard_library
standard_library.install_aliases()
import urllib.request, urllib.parse, urllib.error

from Peach.transformer import Transformer


class UrlEncode(Transformer):
    """URL encode without pluses."""

    def realEncode(self, data):
        return urllib.parse.quote(data)

    def realDecode(self, data):
        return urllib.parse.unquote(data)


class UrlEncodePlus(Transformer):
    """URL encode with pluses."""

    def realEncode(self, data):
        return urllib.parse.quote_plus(data)

    def realDecode(self, data):
        return urllib.parse.unquote_plus(data)
